#ifndef MACROS_H
#define MACROS_H

#define FALSE 0

#define TRUE !FALSE

#define BETWEEN(x_min, x_max, x) (((x) >= (x_min)) && ((x) <= (x_max)))

#endif
